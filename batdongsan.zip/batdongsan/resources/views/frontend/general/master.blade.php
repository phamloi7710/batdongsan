@include('frontend.general.header')
@yield('content')
@yield('script')
@include('frontend.general.footer')          