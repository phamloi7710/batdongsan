@section('title')
Sàn Giao Dịch Bất Động Sản Tecco
@stop
@extends('admin.general.master')
@section('content')
<!-- page content -->
<div class="right_col" role="main">
</div>
@endsection