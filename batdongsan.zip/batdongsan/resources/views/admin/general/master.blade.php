@include('admin.general.header')
@include('admin.general.menu')
@include('admin.general.top')
@yield('content')
@include('admin.general.footer')
@yield('script')
@include('admin.general.notify')
                