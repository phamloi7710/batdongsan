<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class LienHe extends Model
{
    protected $table = "lien_he";
}
